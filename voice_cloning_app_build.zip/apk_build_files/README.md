# Voice Cloning App - APK Build-Paket

Dieses Paket enthält alle notwendigen Dateien, um eine Android-APK für die Voice Cloning App zu erstellen. Es ist speziell für die Verwendung mit Google Colab oder lokalen Buildozer-Installationen optimiert.

## Enthaltene Dateien

- `main_apk.py` - Die Hauptanwendungsdatei mit der Kivy-UI
- `buildozer.spec` - Die Konfigurationsdatei für Buildozer
- `assets/` - Verzeichnis für Ressourcendateien
  - `images/` - Verzeichnis für Bilder
  - `audio/` - Verzeichnis für Audiodateien

## Anleitung für Google Colab

1. Öffnen Sie [Google Colab](https://colab.research.google.com/)
2. Erstellen Sie ein neues Notebook
3. Führen Sie die folgenden Befehle aus:

```python
# Systemabhängigkeiten installieren
!apt-get update
!apt-get install -y git zip unzip openjdk-11-jdk python3-pip autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo-dev cmake libffi-dev libssl-dev wget

# Python-Abhängigkeiten installieren
!pip install cython==0.29.24
!pip install buildozer==1.5.0 pyjnius

# Arbeitsverzeichnis erstellen
!mkdir -p /content/voice_cloning_app
%cd /content/voice_cloning_app

# Hochladen der ZIP-Datei
from google.colab import files
uploaded = files.upload()  # Wählen Sie die ZIP-Datei aus

# Entpacken der ZIP-Datei
!unzip *.zip
!ls -la

# Apache Ant manuell installieren
!mkdir -p .buildozer/android/platform
%cd .buildozer/android/platform
!wget -q https://archive.apache.org/dist/ant/binaries/apache-ant-1.9.4-bin.tar.gz
!tar -xf apache-ant-1.9.4-bin.tar.gz
!rm apache-ant-1.9.4-bin.tar.gz
%cd ../../..

# APK bauen
!buildozer -v android debug

# APK herunterladen
from google.colab import files
apk_files = !find . -name "*.apk"
if len(apk_files) > 0:
    files.download(apk_files[0])
    print(f"APK-Datei {apk_files[0]} wird heruntergeladen...")
else:
    print("Keine APK-Datei gefunden!")
```

## Anleitung für lokalen Build

### Voraussetzungen

- Python 3.9
- Buildozer
- Android SDK und NDK
- Java JDK 11

### Schritte

1. Entpacken Sie die ZIP-Datei in ein Verzeichnis
2. Öffnen Sie ein Terminal und navigieren Sie zu diesem Verzeichnis
3. Führen Sie `buildozer -v android debug` aus
4. Die APK-Datei wird im Verzeichnis `bin/` erstellt

## Fehlerbehebung

Falls Probleme auftreten:

1. Stellen Sie sicher, dass alle Abhängigkeiten korrekt installiert sind
2. Überprüfen Sie die buildozer.log-Datei für detaillierte Fehlerinformationen
3. Versuchen Sie `buildozer clean` und dann erneut `buildozer -v android debug`

## Anpassungen

Sie können die App anpassen, indem Sie:

1. Die `main_apk.py` bearbeiten, um die UI oder Funktionalität zu ändern
2. Die `buildozer.spec` anpassen, um Build-Parameter zu ändern
3. Eigene Bilder oder Audiodateien in die entsprechenden Asset-Verzeichnisse hinzufügen
